# Telegram Messaging Bot 🚀

## 🌟 Features
- Send messages to users
- Send messages to channels
- Send files
- Manage private channels

## 🛠 Requirements
- Python 3.7+
- Telethon
- Colorama

## 📦 Installation
```bash
pip install telethon colorama
```

## 🚀 Usage
```bash
python hyper_bot.py
```

## ⚠️ Warning
- Use the tool responsibly
- Respect Telegram policies
- Do not send spam messages

## 📝 License
MIT License

𝐏𝐑𝐎𝐆𝐑𝐀𝐌𝐌𝐄𝐑: 𝐌𝐘 𝐔𝐒𝐄𝐑 𝐈𝐍 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 @XVSJQ